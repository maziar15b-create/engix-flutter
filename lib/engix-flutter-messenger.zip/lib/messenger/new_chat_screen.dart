import 'dart:async';
import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../core/widgets.dart';
import 'messenger_service.dart';
import 'messenger_tab.dart';

/// جستجوی کاربر (نام یا کد) و شروع گفتگوی مستقیم؛ Chat برمی‌گرداند
class NewChatScreen extends StatefulWidget {
  final String myId;
  const NewChatScreen({super.key, required this.myId});
  @override
  State<NewChatScreen> createState() => _NewChatScreenState();
}

class _NewChatScreenState extends State<NewChatScreen> {
  final _ctrl = TextEditingController();
  Timer? _t;
  List<Map<String, dynamic>> _results = [];
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _t?.cancel();
    _ctrl.dispose();
    super.dispose();
  }

  void _onChanged(String q) {
    _t?.cancel();
    _t = Timer(const Duration(milliseconds: 350), () async {
      try {
        final r = await searchProfiles(q, widget.myId);
        if (mounted) setState(() => _results = r);
      } catch (_) {
        if (mounted) setState(() => _error = 'خطا در جستجو');
      }
    });
  }

  Future<void> _start(Map<String, dynamic> p) async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final id = await getOrCreateDirect(p['id']);
      if (!mounted) return;
      Navigator.pop(
          context,
          Chat(
              id: id,
              type: 'direct',
              title: (p['name'] ?? '').toString(),
              avatarUrl: p['avatar_url']));
    } catch (e) {
      if (mounted) {
        setState(() {
          _busy = false;
          _error = 'ساخت گفتگو ناموفق بود: $e';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('گفتگوی جدید'), backgroundColor: C.bg1),
      body: Backdrop(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
                controller: _ctrl,
                onChanged: _onChanged,
                decoration: const InputDecoration(
                    hintText: 'نام یا کد کاربر را جستجو کنید',
                    prefixIcon: Icon(Icons.search, color: C.muted))),
          ),
          ErrorText(_error),
          if (_busy) const LinearProgressIndicator(color: C.red),
          Expanded(
            child: ListView.builder(
              itemCount: _results.length,
              itemBuilder: (_, i) {
                final p = _results[i];
                final name = (p['name'] ?? '').toString();
                return ListTile(
                  enabled: !_busy,
                  onTap: () => _start(p),
                  leading: avatarOf(p['avatar_url'], name, 42),
                  title: Text(name),
                  subtitle: Text((p['code'] ?? '').toString(),
                      style: const TextStyle(color: C.muted, fontSize: 12)),
                );
              },
            ),
          ),
        ]),
      ),
    );
  }
}
