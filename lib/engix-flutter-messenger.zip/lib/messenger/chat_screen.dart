import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/theme.dart';
import '../core/widgets.dart';
import 'messenger_service.dart';
import 'messenger_tab.dart';

class ChatScreen extends StatefulWidget {
  final Chat chat;
  final String myId;
  const ChatScreen({super.key, required this.chat, required this.myId});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final _db = Supabase.instance.client;

  List<Map<String, dynamic>> _msgs = []; // جدیدترین اول (برای ListView معکوس)
  Map<String, Map<String, dynamic>> _people = {};
  Set<String> _read = {};
  RealtimeChannel? _channel, _readsChannel;
  bool _loading = true, _loadingMore = false, _hasMore = true, _sending = false;
  String? _error;
  Map<String, dynamic>? _editing;

  bool get _isGroup => widget.chat.type != 'direct';

  @override
  void initState() {
    super.initState();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 200) {
        _loadMore();
      }
    });
    _load();
    _subscribe();
  }

  @override
  void dispose() {
    if (_channel != null) _db.removeChannel(_channel!);
    if (_readsChannel != null) _db.removeChannel(_readsChannel!);
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final m = await fetchMessages(widget.chat.id);
      _msgs = m;
      _hasMore = m.length >= 30;
      await _afterChange();
      if (mounted) setState(() => _loading = false);
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'خطا در دریافت پیام‌ها';
        });
      }
    }
  }

  Future<void> _loadMore() async {
    if (_loadingMore || !_hasMore || _msgs.isEmpty) return;
    _loadingMore = true;
    try {
      final older = await fetchMessages(widget.chat.id,
          before: _msgs.last['created_at'].toString());
      _hasMore = older.length >= 30;
      _msgs = [..._msgs, ...older];
      await _afterChange();
      if (mounted) setState(() {});
    } finally {
      _loadingMore = false;
    }
  }

  /// نام فرستنده‌ها، تیک خوانده‌شدن و علامت‌گذاری پیام‌های دریافتی
  Future<void> _afterChange() async {
    final ids = _msgs.map((m) => m['sender_id'] as String).toSet().toList();
    final missing = ids.where((i) => !_people.containsKey(i)).toList();
    if (missing.isNotEmpty) {
      _people = {..._people, ...await fetchProfilesMap(missing)};
    }
    final mine = _msgs
        .where((m) => m['sender_id'] == widget.myId)
        .map((m) => m['id'] as String)
        .toList();
    _read = await fetchReadReceipts(mine);
    if (_msgs.isNotEmpty) {
      markRead(widget.chat.id, widget.myId, _msgs.first['created_at'].toString())
          .catchError((_) {});
    }
  }

  void _subscribe() {
    final f = PostgresChangeFilter(
        type: PostgresChangeFilterType.eq,
        column: 'conversation_id',
        value: widget.chat.id);
    _channel = _db
        .channel('conversation:${widget.chat.id}:app')
        .onPostgresChanges(
            event: PostgresChangeEvent.insert,
            schema: 'public',
            table: 'messages',
            filter: f,
            callback: (p) async {
              final row = Map<String, dynamic>.from(p.newRecord);
              if (_msgs.any((m) => m['id'] == row['id'])) return;
              _msgs = [row, ..._msgs];
              await _afterChange();
              if (mounted) setState(() {});
            })
        .onPostgresChanges(
            event: PostgresChangeEvent.update,
            schema: 'public',
            table: 'messages',
            filter: f,
            callback: (p) {
              final row = Map<String, dynamic>.from(p.newRecord);
              final i = _msgs.indexWhere((m) => m['id'] == row['id']);
              if (i >= 0 && mounted) setState(() => _msgs[i] = row);
            })
        .onPostgresChanges(
            event: PostgresChangeEvent.delete,
            schema: 'public',
            table: 'messages',
            filter: f,
            callback: (p) {
              final id = p.oldRecord['id'];
              if (mounted) setState(() => _msgs.removeWhere((m) => m['id'] == id));
            })
        .subscribe();

    // تیک دوبل: وقتی طرف مقابل پیام‌ها را خواند
    _readsChannel = _db
        .channel('message_reads:${widget.chat.id}:app')
        .onPostgresChanges(
            event: PostgresChangeEvent.insert,
            schema: 'public',
            table: 'message_reads',
            callback: (p) {
              final id = p.newRecord['message_id'];
              if (id is String && mounted) setState(() => _read = {..._read, id});
            })
        .subscribe();
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      if (_editing != null) {
        final id = _editing!['id'] as String;
        await editMessage(id, text);
        final i = _msgs.indexWhere((m) => m['id'] == id);
        if (i >= 0) _msgs[i] = {..._msgs[i], 'content': text, 'is_edited': true};
        _editing = null;
      } else {
        final row = await sendText(widget.chat.id, widget.myId, text);
        if (!_msgs.any((m) => m['id'] == row['id'])) _msgs = [row, ..._msgs];
      }
      _input.clear();
      if (_scroll.hasClients) _scroll.jumpTo(0);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('ارسال ناموفق بود')));
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _onLongPress(Map<String, dynamic> m) {
    if (m['sender_id'] != widget.myId || m['is_deleted'] == true) return;
    showModalBottomSheet(
      context: context,
      backgroundColor: C.bg2,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (m['type'] == 'text')
            ListTile(
              leading: const Icon(Icons.edit),
              title: const Text('ویرایش'),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  _editing = m;
                  _input.text = (m['content'] ?? '').toString();
                });
              },
            ),
          ListTile(
            leading: const Icon(Icons.delete, color: C.danger),
            title: const Text('حذف'),
            onTap: () async {
              Navigator.pop(context);
              try {
                await deleteMessage(m['id']);
                final i = _msgs.indexWhere((x) => x['id'] == m['id']);
                if (i >= 0 && mounted) {
                  setState(() => _msgs[i] = {
                        ..._msgs[i],
                        'is_deleted': true,
                        'content': null
                      });
                }
              } catch (_) {}
            },
          ),
        ]),
      ),
    );
  }

  Widget _bubble(Map<String, dynamic> m) {
    final mine = m['sender_id'] == widget.myId;
    final deleted = m['is_deleted'] == true;
    final t = DateTime.tryParse(m['created_at'].toString())?.toLocal();
    final sender = (_people[m['sender_id']]?['name'] ?? '').toString();
    final isText = m['type'] == 'text';
    return Align(
      alignment:
          mine ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
      child: GestureDetector(
        onLongPress: () => _onLongPress(m),
        child: Container(
          constraints:
              BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
          margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 10),
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
          decoration: BoxDecoration(
            color: mine ? C.redDeep : C.bg3,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: C.line),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (_isGroup && !mine && sender.isNotEmpty)
                Text(sender,
                    style: const TextStyle(
                        color: C.redLight,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w700)),
              Text(
                deleted
                    ? 'این پیام حذف شد'
                    : (isText ? (m['content'] ?? '').toString() : previewOf(m)),
                style: TextStyle(
                    height: 1.6,
                    fontStyle: deleted ? FontStyle.italic : FontStyle.normal,
                    color: deleted ? C.muted : C.text),
              ),
              const SizedBox(height: 2),
              Row(mainAxisSize: MainAxisSize.min, children: [
                if (m['is_edited'] == true && !deleted)
                  const Text('ویرایش‌شده  ',
                      style: TextStyle(color: C.muted, fontSize: 10)),
                Text(timeLabel(t),
                    style: const TextStyle(color: C.soft, fontSize: 10)),
                if (mine && !deleted) ...[
                  const SizedBox(width: 4),
                  Icon(_read.contains(m['id']) ? Icons.done_all : Icons.done,
                      size: 13,
                      color: _read.contains(m['id']) ? C.online : C.soft),
                ],
              ]),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget list;
    if (_loading) {
      list = const Center(child: CircularProgressIndicator(color: C.red));
    } else if (_error != null) {
      list = Center(child: Text(_error!));
    } else if (_msgs.isEmpty) {
      list = const Center(
          child: Text('اولین پیام را بفرستید 👋', style: TextStyle(color: C.muted)));
    } else {
      list = ListView.builder(
        controller: _scroll,
        reverse: true,
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: _msgs.length,
        itemBuilder: (_, i) => _bubble(_msgs[i]),
      );
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: C.bg1,
        titleSpacing: 0,
        title: Row(children: [
          avatarOf(widget.chat.avatarUrl, widget.chat.title, 34),
          const SizedBox(width: 10),
          Expanded(
              child: Text(widget.chat.title,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700))),
        ]),
      ),
      body: Backdrop(
        child: Column(children: [
          Expanded(child: list),
          if (_editing != null)
            Container(
              color: C.bg2,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Row(children: [
                const Icon(Icons.edit, size: 16, color: C.redLight),
                const SizedBox(width: 8),
                const Expanded(
                    child: Text('ویرایش پیام', style: TextStyle(fontSize: 12.5))),
                IconButton(
                    onPressed: () => setState(() {
                          _editing = null;
                          _input.clear();
                        }),
                    icon: const Icon(Icons.close, size: 18)),
              ]),
            ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Expanded(
                  child: TextField(
                    controller: _input,
                    minLines: 1,
                    maxLines: 5,
                    textInputAction: TextInputAction.newline,
                    decoration: const InputDecoration(hintText: 'پیام...'),
                  ),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  width: 48,
                  height: 48,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                        minimumSize: const Size(48, 48),
                        padding: EdgeInsets.zero,
                        shape: const CircleBorder()),
                    onPressed: _sending ? null : _send,
                    child: const Icon(Icons.send, size: 20),
                  ),
                ),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}
