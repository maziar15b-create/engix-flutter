import 'package:supabase_flutter/supabase_flutter.dart';

SupabaseClient get _db => Supabase.instance.client;

class Chat {
  final String id, type, title;
  final String? avatarUrl, lastText;
  final DateTime? lastAt;
  final bool pinned;
  const Chat({
    required this.id,
    required this.type,
    required this.title,
    this.avatarUrl,
    this.lastText,
    this.lastAt,
    this.pinned = false,
  });
}

String previewOf(Map m) {
  if (m['is_deleted'] == true) return 'این پیام حذف شد';
  switch (m['type']) {
    case 'image':
      return '📷 تصویر';
    case 'pdf':
      return '📄 فایل PDF';
    case 'word':
      return '📄 فایل Word';
    case 'voice':
      return '🎤 پیام صوتی';
    default:
      return (m['content'] ?? '').toString();
  }
}

/// لیست گفتگوهای کاربر (همان منطق useChats در نسخه‌ی وب)
Future<List<Chat>> fetchChats(String userId) async {
  final rows = await _db
      .from('conversation_members')
      .select(
          'is_pinned, is_archived, is_hidden, conversations(id, type, name, avatar_url, created_at)')
      .eq('user_id', userId);

  final visible = (rows as List)
      .where((r) =>
          r['conversations'] != null &&
          r['is_hidden'] != true &&
          r['is_archived'] != true)
      .toList();
  if (visible.isEmpty) return [];

  final ids = visible.map((r) => r['conversations']['id'] as String).toList();
  final directIds = visible
      .where((r) => r['conversations']['type'] == 'direct')
      .map((r) => r['conversations']['id'] as String)
      .toList();

  // طرف مقابل گفتگوهای مستقیم
  final otherByConv = <String, String>{};
  if (directIds.isNotEmpty) {
    final members = await _db
        .from('conversation_members')
        .select('conversation_id, user_id')
        .inFilter('conversation_id', directIds);
    for (final m in members as List) {
      if (m['user_id'] != userId) {
        otherByConv[m['conversation_id']] = m['user_id'];
      }
    }
  }
  final profiles = await fetchProfilesMap(otherByConv.values.toList());

  // آخرین پیام هر گفتگو
  final last = <String, Map>{};
  final msgs = await _db
      .from('messages')
      .select('conversation_id, type, content, is_deleted, created_at')
      .inFilter('conversation_id', ids)
      .order('created_at', ascending: false)
      .limit(300);
  for (final m in msgs as List) {
    last.putIfAbsent(m['conversation_id'], () => m);
  }

  final chats = visible.map((r) {
    final c = r['conversations'] as Map;
    final id = c['id'] as String;
    final isDirect = c['type'] == 'direct';
    final other = isDirect ? profiles[otherByConv[id]] : null;
    final lm = last[id];
    return Chat(
      id: id,
      type: c['type'],
      title: isDirect
          ? (other?['name'] ?? 'کاربر حذف‌شده').toString()
          : (c['name'] ?? 'بدون نام').toString(),
      avatarUrl: isDirect ? other?['avatar_url'] : c['avatar_url'],
      lastText: lm == null ? null : previewOf(lm),
      lastAt: DateTime.tryParse((lm?['created_at'] ?? c['created_at']).toString())
          ?.toLocal(),
      pinned: r['is_pinned'] == true,
    );
  }).toList();

  chats.sort((a, b) {
    if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
    return (b.lastAt ?? DateTime(2000)).compareTo(a.lastAt ?? DateTime(2000));
  });
  return chats;
}

Future<Map<String, Map<String, dynamic>>> fetchProfilesMap(
    List<String> ids) async {
  final unique = ids.toSet().toList();
  if (unique.isEmpty) return {};
  final data = await _db
      .from('profiles')
      .select('id, name, code, avatar_url')
      .inFilter('id', unique);
  return {
    for (final p in data as List) p['id'] as String: Map<String, dynamic>.from(p)
  };
}

Future<List<Map<String, dynamic>>> searchProfiles(String q, String myId) async {
  final s = q.trim().replaceAll(RegExp(r'[,()%]'), '');
  if (s.isEmpty) return [];
  final data = await _db
      .from('profiles')
      .select('id, name, code, avatar_url')
      .or('name.ilike.%$s%,code.ilike.%$s%')
      .neq('id', myId)
      .limit(20);
  return List<Map<String, dynamic>>.from(data as List);
}

Future<String> getOrCreateDirect(String otherUserId) async {
  final id =
      await _db.rpc('get_or_create_direct_conversation', params: {'other_user_id': otherUserId});
  return id.toString();
}

Future<List<Map<String, dynamic>>> fetchMessages(String convId,
    {String? before, int limit = 30}) async {
  var q = _db.from('messages').select().eq('conversation_id', convId);
  if (before != null) q = q.lt('created_at', before);
  final data = await q.order('created_at', ascending: false).limit(limit);
  return List<Map<String, dynamic>>.from(data as List); // جدیدترین اول
}

Future<Map<String, dynamic>> sendText(
    String convId, String senderId, String text,
    {String? replyTo}) async {
  final row = await _db
      .from('messages')
      .insert({
        'conversation_id': convId,
        'sender_id': senderId,
        'type': 'text',
        'content': text,
        if (replyTo != null) 'reply_to': replyTo,
      })
      .select()
      .single();
  return Map<String, dynamic>.from(row);
}

Future<void> editMessage(String id, String text) => _db
    .from('messages')
    .update({'content': text, 'is_edited': true}).eq('id', id);

Future<void> deleteMessage(String id) => _db.from('messages').update({
      'is_deleted': true,
      'content': null,
      'file_url': null,
      'file_meta': null
    }).eq('id', id);

Future<void> markRead(String convId, String userId, String upToCreatedAt) async {
  final unread = await _db
      .from('messages')
      .select('id')
      .eq('conversation_id', convId)
      .lte('created_at', upToCreatedAt)
      .neq('sender_id', userId);
  if ((unread as List).isEmpty) return;
  final now = DateTime.now().toUtc().toIso8601String();
  await _db.from('message_reads').upsert([
    for (final m in unread)
      {'message_id': m['id'], 'user_id': userId, 'read_at': now}
  ], onConflict: 'message_id,user_id');
}

/// پیام‌هایی از من که حداقل یک نفر خوانده (برای تیک دوبل)
Future<Set<String>> fetchReadReceipts(List<String> messageIds) async {
  if (messageIds.isEmpty) return {};
  final data = await _db
      .from('message_reads')
      .select('message_id')
      .inFilter('message_id', messageIds);
  return {for (final r in data as List) r['message_id'] as String};
}
