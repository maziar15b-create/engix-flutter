import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/theme.dart';
import 'chat_screen.dart';
import 'messenger_service.dart';
import 'new_chat_screen.dart';

Widget avatarOf(String? url, String name, double size) {
  final has = url != null && url.isNotEmpty;
  return Container(
    width: size,
    height: size,
    alignment: Alignment.center,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      color: C.bg3,
      border: Border.all(color: C.line),
      image: has
          ? DecorationImage(image: NetworkImage(url), fit: BoxFit.cover)
          : null,
    ),
    child: has
        ? null
        : Text(name.isEmpty ? '?' : name.characters.first,
            style: TextStyle(
                fontSize: size * 0.4,
                fontWeight: FontWeight.w700,
                color: C.redLight)),
  );
}

String timeLabel(DateTime? t) {
  if (t == null) return '';
  final now = DateTime.now();
  final hm =
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
  if (t.year == now.year && t.month == now.month && t.day == now.day) return hm;
  return '${t.month}/${t.day}';
}

class MessengerTab extends StatefulWidget {
  final Map<String, dynamic> profile;
  const MessengerTab({super.key, required this.profile});
  @override
  State<MessengerTab> createState() => _MessengerTabState();
}

class _MessengerTabState extends State<MessengerTab> {
  List<Chat>? _chats;
  String? _error;
  RealtimeChannel? _channel;
  Timer? _debounce;

  String get _me => widget.profile['id'] as String;

  @override
  void initState() {
    super.initState();
    _load();
    // با هر پیام جدیدی که RLS اجازه‌ی دیدنش را بدهد، لیست تازه می‌شود
    _channel = Supabase.instance.client
        .channel('chats_list:$_me')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'messages',
          callback: (_) {
            _debounce?.cancel();
            _debounce = Timer(const Duration(milliseconds: 400), _load);
          },
        )
        .subscribe();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    if (_channel != null) Supabase.instance.client.removeChannel(_channel!);
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final c = await fetchChats(_me);
      if (!mounted) return;
      setState(() {
        _chats = c;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      if (_chats == null) setState(() => _error = 'خطا در دریافت گفتگوها');
    }
  }

  Future<void> _open(Chat c) async {
    await Navigator.push(context,
        MaterialPageRoute(builder: (_) => ChatScreen(chat: c, myId: _me)));
    _load();
  }

  Future<void> _newChat() async {
    final chat = await Navigator.push<Chat>(context,
        MaterialPageRoute(builder: (_) => NewChatScreen(myId: _me)));
    if (chat != null && mounted) _open(chat);
  }

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (_error != null) {
      body = Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(_error!),
        const SizedBox(height: 12),
        FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size(140, 44)),
            onPressed: _load,
            child: const Text('تلاش دوباره')),
      ]));
    } else if (_chats == null) {
      body = const Center(child: CircularProgressIndicator(color: C.red));
    } else if (_chats!.isEmpty) {
      body = const Center(
          child: Text('هنوز گفتگویی ندارید.\nبا دکمه‌ی + گفتگوی جدید شروع کنید.',
              textAlign: TextAlign.center, style: TextStyle(color: C.muted)));
    } else {
      body = RefreshIndicator(
        color: C.red,
        onRefresh: _load,
        child: ListView.separated(
          itemCount: _chats!.length,
          separatorBuilder: (_, __) =>
              const Divider(height: 1, color: Color(0x1FC50337)),
          itemBuilder: (_, i) {
            final c = _chats![i];
            return ListTile(
              onTap: () => _open(c),
              leading: avatarOf(c.avatarUrl, c.title, 46),
              title: Row(children: [
                if (c.pinned)
                  const Padding(
                      padding: EdgeInsetsDirectional.only(end: 4),
                      child: Icon(Icons.push_pin, size: 13, color: C.muted)),
                Expanded(
                    child: Text(c.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w700))),
                Text(timeLabel(c.lastAt),
                    style: const TextStyle(color: C.muted, fontSize: 11)),
              ]),
              subtitle: Text(c.lastText ?? '',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: C.soft, fontSize: 12.5)),
            );
          },
        ),
      );
    }
    return Stack(children: [
      Positioned.fill(child: body),
      Positioned(
        left: 16,
        bottom: 16,
        child: FloatingActionButton(
          backgroundColor: C.red,
          foregroundColor: Colors.white,
          onPressed: _newChat,
          child: const Icon(Icons.edit),
        ),
      ),
    ]);
  }
}
